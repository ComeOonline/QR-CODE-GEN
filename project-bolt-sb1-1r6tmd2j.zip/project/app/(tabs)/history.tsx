import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Link,
  Wifi,
  Mail,
  Phone,
  Globe,
  CreditCard,
  ChevronRight,
} from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

const MOCK_HISTORY = [
  {
    id: '1',
    type: 'URL',
    content: 'https://example.com',
    date: '2024-02-20T10:30:00Z',
    icon: Link,
    color: '#007AFF',
  },
  {
    id: '2',
    type: 'WiFi',
    content: 'MyWiFiNetwork',
    date: '2024-02-20T09:15:00Z',
    icon: Wifi,
    color: '#34C759',
  },
  {
    id: '3',
    type: 'Email',
    content: 'contact@example.com',
    date: '2024-02-19T15:45:00Z',
    icon: Mail,
    color: '#FF9500',
  },
  {
    id: '4',
    type: 'Phone',
    content: '+1 234 567 8900',
    date: '2024-02-19T14:20:00Z',
    icon: Phone,
    color: '#FF3B30',
  },
];

export default function HistoryScreen() {
  const renderItem = ({ item, index }) => (
    <Animated.View
      entering={FadeInDown.delay(index * 100)}
      style={styles.itemContainer}>
      <TouchableOpacity style={styles.item}>
        <View style={styles.itemLeft}>
          <View style={[styles.iconContainer, { backgroundColor: item.color + '10' }]}>
            <item.icon size={24} color={item.color} />
          </View>
          <View style={styles.itemContent}>
            <Text style={styles.itemType}>{item.type}</Text>
            <Text style={styles.itemValue} numberOfLines={1}>
              {item.content}
            </Text>
            <Text style={styles.itemDate}>
              {new Date(item.date).toLocaleDateString()}
            </Text>
          </View>
        </View>
        <ChevronRight size={20} color="#8E8E93" />
      </TouchableOpacity>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>History</Text>
        <TouchableOpacity>
          <Text style={styles.clearButton}>Clear All</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={MOCK_HISTORY}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 34,
    fontWeight: '700',
    color: '#000',
  },
  clearButton: {
    fontSize: 17,
    color: '#007AFF',
  },
  list: {
    padding: 20,
  },
  itemContainer: {
    marginBottom: 12,
  },
  item: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  itemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  itemContent: {
    flex: 1,
  },
  itemType: {
    fontSize: 17,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  itemValue: {
    fontSize: 15,
    color: '#666',
    marginBottom: 4,
  },
  itemDate: {
    fontSize: 13,
    color: '#8E8E93',
  },
});