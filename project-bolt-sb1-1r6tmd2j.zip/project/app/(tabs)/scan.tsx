import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, Image as ImageIcon } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { Camera as ExpoCamera } from 'expo-camera';
import Animated, { FadeIn } from 'react-native-reanimated';

export default function ScanScreen() {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanning, setScanning] = useState(false);

  const requestCameraPermission = async () => {
    const { status } = await ExpoCamera.requestCameraPermissionsAsync();
    setHasPermission(status === 'granted');
  };

  const handleScanFromCamera = () => {
    if (hasPermission === null) {
      requestCameraPermission();
    } else if (hasPermission) {
      setScanning(true);
    }
  };

  const handleScanFromGallery = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      // Handle QR code scanning from image
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Animated.View
        entering={FadeIn}
        style={styles.content}>
        <Text style={styles.title}>Scan QR Code</Text>
        <Text style={styles.subtitle}>
          Choose how you'd like to scan your QR code
        </Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={handleScanFromCamera}>
            <Camera size={32} color="#007AFF" />
            <Text style={styles.buttonText}>Scan with Camera</Text>
            <Text style={styles.buttonSubtext}>
              Use your device's camera to scan a QR code
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={handleScanFromGallery}>
            <ImageIcon size={32} color="#34C759" />
            <Text style={styles.buttonText}>Scan from Gallery</Text>
            <Text style={styles.buttonSubtext}>
              Choose a QR code image from your gallery
            </Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  content: {
    padding: 20,
    flex: 1,
  },
  title: {
    fontSize: 34,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 17,
    color: '#666',
    marginBottom: 32,
  },
  buttonContainer: {
    gap: 16,
  },
  button: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  buttonText: {
    fontSize: 17,
    fontWeight: '600',
    color: '#000',
    marginTop: 12,
    marginBottom: 4,
  },
  buttonSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
});