import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  ScrollView,
  Share,
  Linking,
  Alert,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Bell, Cloud, Palette, Share2, Star, CircleHelp as HelpCircle, ChevronRight } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useSettingsStore } from '../store/settingsStore';
import { router } from 'expo-router';

export default function SettingsScreen() {
  const { notifications, cloudBackup, toggleNotifications, toggleCloudBackup } = useSettingsStore();

  const handleShare = async () => {
    try {
      await Share.share({
        message: 'Check out this amazing QR Code app!',
        title: 'QR Code Manager',
        url: 'https://qrcode-manager.app',
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleRateApp = () => {
    const storeUrl = Platform.select({
      ios: 'https://apps.apple.com/app/your-app-id',
      android: 'https://play.google.com/store/apps/details?id=your.app.id',
      default: 'https://qrcode-manager.app',
    });
    Linking.openURL(storeUrl).catch(() => {
      Alert.alert('Error', 'Could not open app store');
    });
  };

  const handleSupport = () => {
    Linking.openURL('mailto:support@qrcode-manager.app').catch(() => {
      Alert.alert('Error', 'Could not open email client');
    });
  };

  const SETTINGS_SECTIONS = [
    {
      title: 'Preferences',
      items: [
        {
          icon: Bell,
          label: 'Notifications',
          type: 'switch',
          color: '#FF9500',
          value: notifications,
          onToggle: toggleNotifications,
        },
        {
          icon: Cloud,
          label: 'Cloud Backup',
          type: 'switch',
          color: '#007AFF',
          value: cloudBackup,
          onToggle: toggleCloudBackup,
        },
        {
          icon: Palette,
          label: 'Appearance',
          type: 'navigate',
          color: '#AF52DE',
          onPress: () => router.push('/appearance'),
        },
      ],
    },
    {
      title: 'General',
      items: [
        {
          icon: Share2,
          label: 'Share App',
          type: 'navigate',
          color: '#34C759',
          onPress: handleShare,
        },
        {
          icon: Star,
          label: 'Rate App',
          type: 'navigate',
          color: '#FF9500',
          onPress: handleRateApp,
        },
        {
          icon: HelpCircle,
          label: 'Help & Support',
          type: 'navigate',
          color: '#5856D6',
          onPress: handleSupport,
        },
      ],
    },
  ];

  const renderSettingItem = (item, index) => (
    <Animated.View
      entering={FadeInDown.delay(index * 100)}
      key={item.label}>
      <TouchableOpacity
        style={styles.settingItem}
        disabled={item.type === 'switch'}
        onPress={item.onPress}>
        <View style={styles.settingItemLeft}>
          <View
            style={[
              styles.iconContainer,
              { backgroundColor: item.color + '10' },
            ]}>
            <item.icon size={24} color={item.color} />
          </View>
          <Text style={styles.settingItemLabel}>{item.label}</Text>
        </View>
        {item.type === 'switch' ? (
          <Switch
            value={item.value}
            onValueChange={item.onToggle}
            trackColor={{ false: '#D1D1D6', true: '#34C759' }}
            ios_backgroundColor="#D1D1D6"
          />
        ) : (
          <ChevronRight size={20} color="#8E8E93" />
        )}
      </TouchableOpacity>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.title}>Settings</Text>

        {SETTINGS_SECTIONS.map((section, sectionIndex) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.sectionContent}>
              {section.items.map((item, index) =>
                renderSettingItem(item, sectionIndex * 3 + index)
              )}
            </View>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={styles.version}>Version 1.0.0</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  scrollView: {
    flex: 1,
  },
  title: {
    fontSize: 34,
    fontWeight: '700',
    color: '#000',
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#000',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  sectionContent: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    marginHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  settingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  settingItemLabel: {
    fontSize: 17,
    color: '#000',
  },
  footer: {
    padding: 20,
    alignItems: 'center',
  },
  version: {
    fontSize: 15,
    color: '#8E8E93',
  },
});