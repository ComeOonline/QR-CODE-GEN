import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, Wifi, Mail, Phone, Globe, CreditCard } from 'lucide-react-native';
import Animated, {
  FadeInDown,
  FadeInUp,
} from 'react-native-reanimated';

const QR_TYPES = [
  { icon: Link, label: 'URL', color: '#007AFF' },
  { icon: Wifi, label: 'WiFi', color: '#34C759' },
  { icon: Mail, label: 'Email', color: '#FF9500' },
  { icon: Phone, label: 'Phone', color: '#FF3B30' },
  { icon: Globe, label: 'Website', color: '#5856D6' },
  { icon: CreditCard, label: 'Payment', color: '#AF52DE' },
];

export default function CreateScreen() {
  const [selectedType, setSelectedType] = useState(QR_TYPES[0]);
  const [content, setContent] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Animated.View
          entering={FadeInDown.delay(200)}
          style={styles.header}>
          <Text style={styles.title}>Create QR Code</Text>
          <Text style={styles.subtitle}>
            Select a type and enter your content
          </Text>
        </Animated.View>

        <Animated.View
          entering={FadeInDown.delay(400)}
          style={styles.typeContainer}>
          <Text style={styles.sectionTitle}>QR Code Type</Text>
          <View style={styles.typeGrid}>
            {QR_TYPES.map((type) => (
              <TouchableOpacity
                key={type.label}
                style={[
                  styles.typeButton,
                  selectedType.label === type.label && styles.selectedType,
                ]}
                onPress={() => setSelectedType(type)}>
                <type.icon
                  size={24}
                  color={type.color}
                  style={styles.typeIcon}
                />
                <Text style={styles.typeLabel}>{type.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        <Animated.View
          entering={FadeInUp.delay(600)}
          style={styles.inputContainer}>
          <Text style={styles.sectionTitle}>Content</Text>
          <TextInput
            style={styles.input}
            placeholder={`Enter ${selectedType.label.toLowerCase()} content...`}
            value={content}
            onChangeText={setContent}
            multiline
          />
          <TouchableOpacity style={styles.generateButton}>
            <Text style={styles.generateButtonText}>Generate QR Code</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
  },
  title: {
    fontSize: 34,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 17,
    color: '#666',
  },
  typeContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 16,
    color: '#000',
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeButton: {
    width: '30%',
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  selectedType: {
    backgroundColor: '#F8F8F8',
    borderWidth: 2,
    borderColor: '#007AFF',
  },
  typeIcon: {
    marginBottom: 8,
  },
  typeLabel: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  inputContainer: {
    padding: 20,
  },
  input: {
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    minHeight: 120,
    textAlignVertical: 'top',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  generateButton: {
    backgroundColor: '#007AFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  generateButtonText: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '600',
  },
});