import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface SettingsState {
  notifications: boolean;
  cloudBackup: boolean;
  toggleNotifications: () => void;
  toggleCloudBackup: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      notifications: false,
      cloudBackup: false,
      toggleNotifications: () =>
        set((state) => ({ notifications: !state.notifications })),
      toggleCloudBackup: () =>
        set((state) => ({ cloudBackup: !state.cloudBackup })),
    }),
    {
      name: 'settings-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);